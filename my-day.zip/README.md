<h1>Here is my Sample task for Wiredelta!</h1>

<p>I created a small web application whihch allows you to organize your day in order to get the best use of it. This web-app has first a top bar which show you the date and the clock in real time. It also includes a dropdown which allows the user to switch themes in order to have a greater experience while using it. For example, let's say you are in the bed ready to fall asleep and you want to look at your tasks for tomorrow. First thing you can choose a darker theme which will make it pleasant for your eye and then start looking into tomorrow's tasks (be aware, you want be able to take control of them until the clock hits 0:00).
  </p>

<b>Enjoy and be ready to have better and better days!</b>
